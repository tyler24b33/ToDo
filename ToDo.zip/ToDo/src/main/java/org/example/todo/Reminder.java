package org.example.todo;

public class Reminder {


    public Reminder() {

    }

}
