# Tyler-CSI-2300-Course-Project
1. Your project name, Tyler Birmingham
2. I am trying to build a To Do  Task Scheduling App That has a Very Simplistic View To not Overwhelm Users, I want to Build it Because I have problems with Other apps Where you have to pay for a month view and Have a view of soon to do Tasks. It will be Useful To Schedule Asignments, Mettings, etc It will allow you to see soon ToDo events at a Glance
3.
![image](https://github.com/user-attachments/assets/b98f8520-6a28-460f-958c-5043f1e9aae5).

4. Plan and estimate of effortCoding, Devloping, Impleting etc 100% effort By Me.
 
5.) updated uml diagram 
![image](https://github.com/user-attachments/assets/61e900ba-8a34-4228-aace-3d6b84441568)
